// Native
import events from "events";
import path from "path";

// Packages
import { BrowserWindow, app, ipcMain, IpcMainEvent } from "electron";
import isDev from "electron-is-dev";
import prepareNext from "electron-next";

// Prepare the renderer once the app is ready

const main = async () => {
  await events.once(app, "ready");
  await prepareNext("./renderer");

  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      // In Electron 12, the default will be changed to true.
      worldSafeExecuteJavaScript: true,
      // XSS対策としてnodeモジュールをレンダラープロセスで使えなくする
      //default is false so you can omit this line safely.
      nodeIntegration: false,
      // レンダラープロセスに公開するAPIのファイル
      //（Electron 11 から、デフォルト：falseが非推奨となった）
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
    },
  });

  const url = isDev
    ? "http://localhost:8000/"
    : new URL(path.resolve(__dirname, "../renderer/out/index.html"), "file://")
        .href;

  mainWindow.loadURL(url);
};

// Quit the app once all windows are closed
app.on("window-all-closed", app.quit);

// listen the channel `message` and resend the received message to the renderer process
ipcMain.on("message", (event: IpcMainEvent, message: any) => {
  console.log(message);
  setTimeout(() => event.sender.send("message", "hi from electron"), 500);
});

/*!*************************************************************************************************
                                                MAIN
***************************************************************************************************/

main();
