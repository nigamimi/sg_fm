"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.methods = exports.apiKeyName = void 0;
/* eslint-disable @typescript-eslint/no-namespace */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const electron_1 = require("electron");
exports.apiKeyName = "electronMain";
exports.methods = {
    send: (message) => {
        electron_1.ipcRenderer.send("message", message);
    },
    listen: (listener) => {
        electron_1.ipcRenderer.addListener("message", listener);
    },
};
electron_1.contextBridge.exposeInMainWorld(exports.apiKeyName, exports.methods);
