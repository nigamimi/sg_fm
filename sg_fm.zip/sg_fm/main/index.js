"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Native
const events_1 = __importDefault(require("events"));
const path_1 = __importDefault(require("path"));
// Packages
const electron_1 = require("electron");
const electron_is_dev_1 = __importDefault(require("electron-is-dev"));
const electron_next_1 = __importDefault(require("electron-next"));
// Prepare the renderer once the app is ready
const main = async () => {
    await events_1.default.once(electron_1.app, "ready");
    await electron_next_1.default("./renderer");
    const mainWindow = new electron_1.BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            // In Electron 12, the default will be changed to true.
            worldSafeExecuteJavaScript: true,
            // XSS対策としてnodeモジュールをレンダラープロセスで使えなくする
            //default is false so you can omit this line safely.
            nodeIntegration: false,
            // レンダラープロセスに公開するAPIのファイル
            //（Electron 11 から、デフォルト：falseが非推奨となった）
            contextIsolation: true,
            preload: path_1.default.join(__dirname, "preload.js"),
        },
    });
    const url = electron_is_dev_1.default
        ? "http://localhost:8000/"
        : new URL(path_1.default.resolve(__dirname, "../renderer/out/index.html"), "file://")
            .href;
    mainWindow.loadURL(url);
};
// Quit the app once all windows are closed
electron_1.app.on("window-all-closed", electron_1.app.quit);
// listen the channel `message` and resend the received message to the renderer process
electron_1.ipcMain.on("message", (event, message) => {
    console.log(message);
    setTimeout(() => event.sender.send("message", "hi from electron"), 500);
});
/*!*************************************************************************************************
                                                MAIN
***************************************************************************************************/
main();
